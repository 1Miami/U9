package Att3;

public class FuncionarioProducao extends Usuario {
    private Pedido pedidoResponsavel;

    public FuncionarioProducao(String nome, int ID, String cargo, Pedido pedidoResponsavel) {
        super(nome, ID, cargo);
        this.pedidoResponsavel = pedidoResponsavel;
    }

    // Getters e Setters
}
