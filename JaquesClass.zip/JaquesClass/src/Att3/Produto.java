package Att3;

public class Produto {
    private TipoProduto tipo;
    private double precoBase;

    public Produto(TipoProduto tipo, double precoBase) {
        this.tipo = tipo;
        this.precoBase = precoBase;
    }

    // Getters e Setters
}
