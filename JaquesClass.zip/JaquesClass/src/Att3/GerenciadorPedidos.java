package Att3;

import java.util.ArrayList;
import java.util.List;

public class GerenciadorPedidos {
    private List<Pedido> pedidos;

    public GerenciadorPedidos() {
        this.pedidos = new ArrayList<>();
    }

    // Método para adicionar um novo pedido
    public void adicionarPedido(Pedido pedido) {
        pedidos.add(pedido);
    }

    // Método para exibir todos os pedidos
    public void exibirPedidos() {
        for (Pedido pedido : pedidos) {
            System.out.println("Data de Emissão: " + pedido.getDataEmissao());
            System.out.println("Preço: " + pedido.getPreco());
            System.out.println("Tipo de Produto: " + pedido.getTipoProduto());
            System.out.println("Funcionário de Vendas: " + pedido.getFuncionarioVendas().getNome());
            System.out.println();
        }
    }
}
