package Att3;

import java.util.Date;

public class Main {
    public static void main(String[] args) {
        // Criando usuários
        Gerente gerenteFinanceiro = new Gerente("João", 1, "Gerente Financeiro", "Financeiro");
        Empregado empregado1 = new Empregado("Maria", 2, "Operador de Máquinas");
        EmpregadoTerceirizado empregadoTerceirizado = new EmpregadoTerceirizado("Pedro", 3, "Limpeza");

        // Criando produtos
        Produto produtoBanner = new Produto(TipoProduto.BANNER, 50.0);
        Produto produtoLivro = new Produto(TipoProduto.LIVRO, 20.0);

        // Criando pedidos
        Pedido pedido1 = new Pedido(new Date(), 100.0, TipoProduto.BANNER, gerenteFinanceiro);
        Pedido pedido2 = new Pedido(new Date(), 200.0, TipoProduto.LIVRO, gerenteFinanceiro);

        // Criando funcionários de produção
        FuncionarioProducao funcionarioProducao1 = new FuncionarioProducao("Lucas", 4, "Impressor", pedido1
