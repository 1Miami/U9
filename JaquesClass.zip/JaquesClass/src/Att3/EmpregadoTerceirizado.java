package Att3;

public class EmpregadoTerceirizado extends Usuario {
    public EmpregadoTerceirizado(String nome, int ID, String cargo) {
        super(nome, ID, cargo);
    }
}
