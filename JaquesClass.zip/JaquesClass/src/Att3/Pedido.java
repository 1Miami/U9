package Att3;

import java.util.Date;

public class Pedido {
    private Date dataEmissao;
    private double preco;
    private TipoProduto tipoProduto;
    private Usuario funcionarioVendas;

    public Pedido(Date dataEmissao, double preco, TipoProduto tipoProduto, Usuario funcionarioVendas) {
        this.dataEmissao = dataEmissao;
        this.preco = preco;
        this.tipoProduto = tipoProduto;
        this.funcionarioVendas = funcionarioVendas;
    }

    public Date getDataEmissao() {
        return dataEmissao;
    }

    public double getPreco() {
        return preco;
    }

    public TipoProduto getTipoProduto() {
        return tipoProduto;
    }

    public Usuario getFuncionarioVendas() {
        return funcionarioVendas;
    }
}
