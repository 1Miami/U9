package Att3;

public class Empregado extends Usuario {
    public Empregado(String nome, int ID, String cargo) {
        super(nome, ID, cargo);
    }
}
